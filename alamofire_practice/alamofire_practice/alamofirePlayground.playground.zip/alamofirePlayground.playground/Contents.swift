
import Foundation
import UIKit
import Alamofire

// MARK: 구조체 선언 부분
struct multipartStruct: Codable {
    var title: String
    var number: Int
    
    init(title: String, number: Int){
        self.title = title
        self.number = number
    }
}

//var images = [UIImage]()
//
//var data = [Data]()
//for i in images.count {
//    let imageData = images[i].jpegData(compressionQuality: 0.5)
//    data.append(imageData!)
//}
//

// MARK: 파라미터 선언 부분
let multipartParam: [multipartStruct] = [
    multipartStruct(title: "title1", number: 1),
    multipartStruct(title: "title2", number: 2),
]

let parameters: [String: [String]] = [
    "foo": ["bar"],
    "baz": ["a", "b"],
    "qux": ["x", "y", "z"]
]



// MARK: 함수 선언 부분
func testGetRequest(url: URL) {
    AF.request(url).response { response in
        debugPrint(response)
    }
}

func testPostRequest(url: URL) {
    AF.request(url, method: .post, parameters: parameters, encoding: JSONEncoding.default).response { response in
        debugPrint(response)
    }
}


//testGetRequest(url: URL(string: "http://13.124.90.96:8080/api/v1/testing/test")!)
//testPostRequest(url: URL(string: "http://13.124.90.96:8080/api/v1/testing/test")!)



// MARK: 성공사례
let urlpath = Bundle.main.path(forResource: "IMG_5688", ofType: "JPG")
let url = URL(fileURLWithPath: urlpath!)

func testMultipartUpload(to: URL, url: URL) {
    
    let fileName = url.lastPathComponent
    guard let imageFile: Data = try? Data (contentsOf: url) else {return}
    AF.upload(multipartFormData: { (multipartFormData) in
        multipartFormData.append(imageFile, withName: "image", fileName: fileName, mimeType: "image/jpg")
    }, to: to).responseJSON { (response) in
        debugPrint(response)
    }

}


testMultipartUpload(
    to: URL(string: "http://13.124.90.96:8080/api/v1/testing/image")!,
    url: url
)
